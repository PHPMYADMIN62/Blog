<?php

setcookie('id_utilisateur', '', -1); //on définit le cookie qui sera envoyé

header("Location: Index.php"); //retour sur la page d'accueil

exit();

?>