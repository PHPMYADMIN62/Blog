<?php

require_once 'config/Init.conf.php';
require_once 'include/Fonctions.inc.php';
require_once 'config/Bdd.conf.php';
require_once 'config/Connexion.conf.php';
include_once 'include/Header.inc.php';

/* @var $bdd PDO */

if (isset($_GET['action']) && isset($_GET['id'])) {

    $id_article = $_GET['id'];

    $req = $bdd->prepare('SELECT * FROM article WHERE id = ' . $id_article);
    $req->execute();
    $article = $req->fetch();

    if (!empty(filter_input(INPUT_POST, 'submit'))) { //si on appuie sur le bouton ajouter
        $titre_nouveau = $_POST['titre'];
        $texte_nouveau = $_POST['texte'];

        $publie_nouveau = isset($_POST['publie']) ? 1 : 0;

        $date_nouveau = date('Y-m-d'); //on met la date au format suivant

        $sth = $bdd->prepare("UPDATE article " //on prépare la requête de modification de l'article dans la base de données
                . "SET titre=:titre_nouveau, texte=:texte_nouveau, publie=:publie_nouveau, date=:date_nouveau "
                . "WHERE id=" . $id_article);
        $sth->bindValue(':titre_nouveau', $titre_nouveau, PDO::PARAM_STR);
        $sth->bindValue(':texte_nouveau', $texte_nouveau, PDO::PARAM_STR);
        $sth->bindValue(':publie_nouveau', $publie_nouveau, PDO::PARAM_BOOL);
        $sth->bindValue(':date_nouveau', $date_nouveau, PDO::PARAM_STR);

        $sth->execute(); //on exécute la requête

        if ($_FILES['img']['error'] == 0) {
            move_uploaded_file($_FILES['img']['tmp_name'], 'img/' . $id_article . '.jpg'); //on ajoute l'image avec son nom au format .jpg dans le dossier img
        }

        $message = 'Votre article a été modifié avec succès !'; //message succès d'une modification
        $result = 'success'; 

        declareNotification($message, $result);

        header("Location: Index.php"); //Utilisateur redirigé vers l'accueil

        exit(); //fin du script
    }
} else {
    if (!empty(filter_input(INPUT_POST, 'submit'))) { 
        $texte = filter_input(INPUT_POST, 'texte');

        $publie = isset($_POST['publie']) ? 1 : 0; 

        $date = date('Y-m-d'); 

        $sth = $bdd->prepare("INSERT INTO article "
                . "(titre, texte, publie, date) "
                . "VALUES (:titre, :texte, :publie, :date)");
        $sth->bindValue(':titre', $titre, PDO::PARAM_STR);
        $sth->bindValue(':texte', $texte, PDO::PARAM_STR);
        $sth->bindValue(':publie', $publie, PDO::PARAM_BOOL);
        $sth->bindValue(':date', $date, PDO::PARAM_STR);

        $sth->execute(); 

        $id_article = $bdd->lastInsertId(); 

        if ($_FILES['img']['error'] == 0) {
            move_uploaded_file($_FILES['img']['tmp_name'], 'img/' . $id_article . '.jpg');
        }

        $message = 'Votre article a été ajouté !'; 
        $result = 'success'; 

        declareNotification($message, $result);

        header("Location: Index.php"); 

        exit();
    }
}

$smarty = new Smarty(); //nouvel objet Smarty

$smarty->setTemplateDir('Template/'); //les fichirs .tpl seront enregistrés dans le dossier Template
$smarty->setCompileDir('Templates_c/'); //les fichiers de compilation de template seront enregistrés dans le dossier Templates_c

$smarty->display('Templates/Article.tpl'); //on affiche le template suivant

unset($_SESSION['notification']);

exit();

?>
