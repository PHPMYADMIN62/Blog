<?php

function print_r2($ma_variable) {
    echo '<pre>';
    print_r($ma_variable); //on affiche des informations pour une variable
    echo '</pre>';

    return true;
}

function declareNotification($message, $result) { //à partir d'une notification, on affiche le message et le résultat
    $_SESSION['notification']['message'] = $message;
    $_SESSION['notification']['result'] = $result;

    return true;
}

function countArticles($bdd) { //nombre d'article dans la BDD

    /* @var $bdd PDO */

    $sth = $bdd->prepare("SELECT COUNT(*) as total "
            . "FROM article "
            . "WHERE publie = :publie");
    $sth->bindValue(':publie', 1, PDO::PARAM_BOOL);
    $sth->execute();
    $result = $sth->fetch(PDO::FETCH_ASSOC);

    return $result['total'];
}

function returnIndex($page_courante, $nb_articles_par_page) { //fonction pour la pagination
    $index_depart = ($page_courante - 1) * $nb_articles_par_page;

    return $index_depart;
}

?>