<!DOCTYPE html>
<html lang="fr">

<!-- Cette page est utilisée pour les menus proposés sur le blog qui se présentent sous forme de lien de page -->

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Mon blog</title>

        <!-- Bootstrap core CSS -->

        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    </head>

    <body>

        <!-- Navigation sur le blog -->

        <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
            <div class="container">
                <a class="navbar-brand" href="Index.php">Bienvenue sur mon blog !</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <form method="GET" action="Rechercher.php" class="form-inline my-2 my-lg-0">
                            <input class="form-control mr-sm-2" type="search" aria-label="Search" name="rechercher">
                            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pour aller plus vite</button>
                        </form>
                        <li class="nav-item active">
                            <a class="nav-link" href="Index.php">Accueil du blog</a>
                        </li>

                        <?php
                        if ($connecte == true) { //si connexion OK
                            ?>
                            <li class="nav-item">
                                <a class="nav-link" href="Article.php">Ajouter un nouvel article</a>
                            </li>
                            <?php
                        }
                        ?>
                        <li class="nav-item">
                            <a class="nav-link" href="Utilisateur.php">Ajouter un nouvel utilisateur</a>
                        </li>
                        <?php
                            if ($connecte == false) { //si connexion KO
                        ?>
                        <li class="nav-item">
                            <a class="nav-link" href="Connexion.php">Se connecter</a>
                        </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="Deconnexion.php">Se déconnecter</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>


