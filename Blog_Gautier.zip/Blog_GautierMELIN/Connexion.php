<?php

require_once 'config/Init.conf.php';
require_once 'include/Fonctions.inc.php';
require_once 'config/Bdd.conf.php';
require_once 'config/Connexion.conf.php';
include_once 'include/Header.inc.php';

if (!empty($_POST['submit'])) {
    $email = filter_input(INPUT_POST, 'email');
    $motdepasse = sha1(filter_input(INPUT_POST, 'motdepasse')); //on calcule le mot de passe

    $sth = $bdd->prepare("SELECT * "
            . "FROM utilisateur "
            . "WHERE email = :email AND motdepasse = : motdepasse");
    $sth->bindValue(':email', $email, PDO::PARAM_STR); //on sécurise les paramètres
    $sth->bindValue(':motdepasse', $motdepasse, PDO::PARAM_STR);

    $sth->execute(); //on exécute la requête

    if ($sth->rowCount() > 0) {
        $donnees = $sth->fetch(PDO::FETCH_ASSOC);
        $id_utilisateur = $donnees['email'] . time();
        $id_utilisateur_hache = md5($id_utilisateur);

        setcookie('id_utilisateur', $id_utilisateur_hache, time() + 3600); //on déclare un cookie sid

        $sth_update = $bdd->prepare("UPDATE utilisateur" 
                . "SET id_utilisateur = :si id_utilisateur"
                . "WHERE id = : id");

        $sth_update->bindValue(':id_utilisateur', $id_utilisateur_hache, PDO::PARAM_STR);
        $sth_update->bindValue(':id', $donnees['id'], PDO::PARAM_INT);

        $result_connexion = $sth_update->execute();

        if ($result_connexion == TRUE) {
            $_SESSION['notification']['result'] = 'success';
            $_SESSION['notification']['message'] = 'Vous êtes connecté !';
        } else {
            $_SESSION['notification']['result'] = 'danger';
            $_SESSION['notification']['message'] = 'Une erreur s\'est produite, vous n\'êtes pas connecté !';
        }

        header("location: Index.php");
        exit();
    } else {

        //la connexion est refusée

        $_SESSION['notification']['result'] = 'danger';
        $_SESSION['notification']['message'] = '<b>Attention !</b> Veuillez vérifier vos identifiant et mot de passe.';

        //Redirection vers l'accueil

        header("location: Connexion.php");
        
        exit();
    }
} else {

   $smarty = new Smarty(); //nouvel objet Smarty

$smarty->setTemplateDir('Template/'); //les fichirs .tpl seront enregistrés dans le dossier Template
$smarty->setCompileDir('Templates_c/'); //les fichiers de compilation de template seront enregistrés dans le dossier Templates_c

$smarty->display('Templates/Connexion.tpl'); //on affiche le template suivant

unset($_SESSION['notification']);

exit();

?>