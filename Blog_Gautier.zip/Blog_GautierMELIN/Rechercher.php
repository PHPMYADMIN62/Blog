<?php

require_once 'config/Init.conf.php';
require_once 'include/Fonctions.inc.php';
require_once 'config/Bdd.conf.php';
require_once 'config/Connexion.conf.php';
include_once 'include/Header.inc.php';

if (isset($_GET['rechercher'])) {

    /* @var $bdd PDO */

    $page_courante = !empty($_GET['p']) ? $_GET['p'] : 1; 

    $nb_total_articles = countArticles($bdd); //nombre total d'articles présents dans la base de données

    $index_depart = returnIndex($page_courante, _nb_articles_par_page_);

    $nb_total_pages = ceil($nb_total_articles / _nb_articles_par_page_);

    $select_articles = "SELECT" //requête pour afficher les informations d'un article

            . "titre, "
            . "texte, "
            . "DATE_FORMAT(date, '%d/%m/%Y') AS date_fr, "
            . "publie "
            . "FROM article "
            . "WHERE publie = :publie "
            . "AND (titre LIKE : rechercher OR texte LIKE : rechercher) "
            . "LIMIT :index_depart, :nb_articles_par_page";

    $sth = $bdd->prepare($select_articles);
    $sth->bindValue(":publie", 1, PDO::PARAM_BOOL);
    $sth->bindValue(":index_depart", $index_depart, PDO::PARAM_INT);
    $sth->bindValue(":nb_articles_par_page", _nb_articles_par_page_, PDO::PARAM_INT);
    $sth->bindValue(":rechercher", '%' . $_GET['rechercher'] . '%', PDO::PARAM_STR);
    $sth->execute(); //on exécute la requête

    $tab_result = $sth->fetchAll(PDO::FETCH_ASSOC);
}

$smarty = new Smarty(); //nouvel objet Smarty

$smarty->setTemplateDir('Template/'); //les fichirs .tpl seront enregistrés dans le dossier Template
$smarty->setCompileDir('Templates_c/'); //les fichiers de compilation de template seront enregistrés dans le dossier Templates_c
 
$smarty->assign('tab_result', $tab_result);

$smarty->display('Templates/Rechercher.tpl');
unset($_SESSION['notification']);

exit();

?>