<?php

require_once 'config/Init.conf.php';
require_once 'include/Fonctions.inc.php';
require_once 'config/Bdd.conf.php';
require_once 'config/Connexion.conf.php';
include_once 'include/Header.inc.php';

/* @var $bdd PDO */

if (!empty(filter_input(INPUT_POST, 'submit'))) {
    $nom = filter_input(INPUT_POST, 'nom');
    $prenom = filter_input(INPUT_POST, 'prenom');
    $email = filter_input(INPUT_POST, 'email');
    $mdp = sha1(filter_input(INPUT_POST, 'motdepasse')); //on crypte le mot de passe

    $sth = $bdd->prepare("INSERT INTO utilisateur "
            . "(nom, prenom, email, motdepasse) "
            . "VALUES (:nom, :prenom, :email, :motdepasse)");
    $sth->bindValue(':nom', $nom, PDO::PARAM_STR);
    $sth->bindValue(':prenom', $prenom, PDO::PARAM_STR);
    $sth->bindValue(':email', $email, PDO::PARAM_STR);
    $sth->bindValue(':motdepasse', $mdp, PDO::PARAM_STR);

    $sth->execute(); //on exécute la requête

    $message = 'Votre compte a été créé avec succès !';
    $result = 'success';

    declareNotification($message, $result);

    header("Location: Index.php");

    exit(); //fin du script
}

$smarty = new Smarty(); //nouvel objet Smarty

$smarty->setTemplateDir('Template/'); //les fichirs .tpl seront enregistrés dans le dossier Template
$smarty->setCompileDir('Templates_c/'); //les fichiers de compilation de template seront enregistrés dans le dossier Templates_c

$smarty->display('Templates/Utilisateur.tpl'); //on affiche le template suivant

unset($_SESSION['notification']);

exit();

?>