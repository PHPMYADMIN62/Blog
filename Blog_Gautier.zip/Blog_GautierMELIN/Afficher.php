<?php

require_once 'config/Init.conf.php';
require_once 'include/Fonctions.inc.php';
require_once 'config/Bdd.conf.php';
require_once 'config/Connexion.conf.php';
include_once 'include/Header.inc.php';


    $id = $_GET['id'];//on récupère l'ID
    
    //on affiche l'article
    $sth = $bdd->prepare("SELECT article.id, "
            ."titre, "
            ."texte, "
            ."pseudo, "
            ."contenu, "
            ."id_article " 
            ."FROM article " 
            ."LEFT JOIN commenaire ON commentaire.id_article=article.id "
            ."WHERE article.id=:id");
    
    $sth->bindValue(':id', $id, PDO::PARAM_INT);
    
    $sth->execute(); //on exécute la requête
    $article = $sth->fetchAll(PDO::FETCH_ASSOC); //retourne un tableau contenant toutes les lignes

$smarty = new Smarty(); //nouvel objet Smarty

$smarty->setTemplateDir('Template/'); //les fichirs .tpl seront enregistrés dans le dossier Template
$smarty->setCompileDir('Templates_c/'); //les fichiers de compilation de template seront enregistrés dans le dossier Templates_c

$smarty->assign('article', $article);

$smarty->display('Templates/Afficher.tpl'); //on affiche le template suivant

unset($_SESSION['notification']);

exit();

?>