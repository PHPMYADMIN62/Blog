<?php

require_once 'config/Init.conf.php';
require_once 'include/Fnctions.inc.php';
require_once 'config/Bdd.conf.php';
require_once 'config/Connexion.conf.php';
include_once 'include/Header.inc.php';

if (!empty($_POST['submit'])) {

    $pseudo = $_POST['pseudo'];
    $email = $_POST['email'];
    $contenu = $_POST['contenu'];
    $id_article = $_POST['id'];

    //requête sql permettant d'ajouter un commentaire à la base de données grâce aux données récupérées par les champs du formulaire

    $sth = $bdd->prepare("INSERT INTO commentaire "
            . "(pseudo, email, contenu, id) "
            . "VALUES (:pseudo, :email, :contenu, : id)");

    $sth->bindValue(':pseudo', $pseudo, PDO::PARAM_STR);
    $sth->bindValue(':email', $email, PDO::PARAM_STR);
    $sth->bindValue(':contenu', $contenu, PDO::PARAM_STR);
    $sth->bindValue(':id', $id, PDO::PARAM_INT);

    $sth->execute(); //on exécute la requête sql

    $message = 'Votre commentaire a été ajouté !';
    $result = 'success';

    declareNotification($message, $result); //on affiche le message de notification

    header("Location: Afficher.php?id=$id_article&action=Afficher"); //retour sur la page de l'article après validation du commentaire

    exit(); //fin du script
}


?>