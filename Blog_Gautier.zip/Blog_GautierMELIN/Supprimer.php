<?php

require_once 'config/Init.conf.php';
require_once 'include/Fonctions.inc.php';
require_once 'config/Bdd.conf.php';
require_once 'config/Connexion.conf.php';
include_once 'include/Header.inc.php';

if (isset($_GET['action']) && isset($_GET['id'])) { //si on appuie sur le bouton supprimer

    $id = $_GET['id']; //on récupère l'ID de l'article
    $sth = $bdd->prepare("DELETE FROM article where article.id=$id"); //on supprime l'article de la table
    $sth->bindValue(':id', $id, PDO::PARAM_INT);
    $sth->execute(); //on exécute la requête

    $message = 'Votre article a été supprimé !';
    $result = 'success';

    declareNotification($message, $result); //on affiche le message

    header("Location: Index.php"); //Retour sur la page d'acueil

    exit(); //fin du script

}

?>

