<?php

session_start(); //démarre une session


error_reporting(E_ALL);
ini_set("display_errors", 1); //affiche les erreurs

define('_nb_articles_par_page_', 6); //définir le nombre d'article par page

date_default_timezone_set('Europe/Paris'); //définir le fuseau horaire utilisé

?>