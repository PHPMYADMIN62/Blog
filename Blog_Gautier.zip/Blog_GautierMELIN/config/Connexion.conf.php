<?php

/* @var $bdd PDO */
$connecte = FALSE; //dans le cas où il n'y a pas de compte connecté

if (isset($_COOKIE['id_utilisateur'])) { //dans le cas où le cookie est déclaré
    $sid = $_COOKIE['id_utilisateur'];
    $sth_connexion = $bdd->prepare("SELECT * " //on récupère les données de la table en référence au id_utilisateur
            . "FROM utilisateur "
            . "WHERE id_utilisateur = : id_utilisateur"
    $sth_connexion->bindValue(':id_utilisateur', $id_utilisateur, PDO::PARAM_STR);
    $sth_connexion->execute(); //on exécute la requête sql
    if ($sth_connexion->rowCount() > 0) { //si la requête renvoie au moins une ligne correcte
    $connecte = TRUE; //la connexion est établie
    }
}

?>