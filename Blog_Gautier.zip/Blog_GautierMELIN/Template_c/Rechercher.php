<?php

if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '',
  'unifunc' => '',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '' => 
    array (
      0 => 'C:\\wamp64\\www\\Blog\\Templates\\Rechercher.tpl',
      1 => 'file',
    ),
  ),
  array (
  ),
),false)) {
function (Smarty_Internal_Template $_smarty_tpl) {

?>

<!-- Ce qui se passe quand on effectue une recherche -->

<?php if (!empty($_GET['rechercher'])) {?> 

    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_result']->value, 'valeur');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['valeur']->value) {
?>
        <div class="col-7">
            <div class="card" style="width: 100%;">
                <img src="img/<?php echo $_smarty_tpl->tpl_vars['valeur']->value['id'];?>
.jpg" class="card-img-top" alt="<?php echo $_smarty_tpl->tpl_vars['valeur']->value['titre'];?>
">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $_smarty_tpl->tpl_vars['valeur']->value['titre'];?></h5>
                    <p class="card-text"><?php echo $_smarty_tpl->tpl_vars['valeur']->value['texte'];?></p>
                    <a href="#" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['valeur']->value['date_fr'];?></a>
                    <a href="Article.php?id=<?php echo $_smarty_tpl->tpl_vars['valeur']->value['id'];?>
                    &action=modifier" class="btn btn-primary">Modifier</a>
                    <a href="afficher.php?id=<?php echo $_smarty_tpl->tpl_vars['valeur']->value['id'];?>
                    &action=afficher" class="btn btn-primary">Afficher</a>
                    <a href="supprimer.php?id=<?php echo $_smarty_tpl->tpl_vars['valeur']->value['id'];?>
                    &action=supprimer" class="btn btn-primary">Supprimer</a>
                </div>
            </div>
        </div>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
}
}
