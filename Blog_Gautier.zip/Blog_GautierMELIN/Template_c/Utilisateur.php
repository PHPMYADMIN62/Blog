<?php

if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '',
  'unifunc' => '',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '' => 
    array (
      0 => 'C:\\wamp64\\www\\Blog\\Templates\\Utilisateur.tpl',
      1 => 'file',
    ),
  ),
  array (
  ),
),false)) {
function (Smarty_Internal_Template $_smarty_tpl) {

?>

<!-- Page Content -->

<div class="container">
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1 class="mt-5">Nouvel utilisateur</h1>
        </div>
    </div>

    <!-- Nouvel utilisateur sur le blog -->

    <div class="row">
        <div class="col-12">
            <form method="POST" action="Utilisateur.php" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="nom">Votre nom</label>
                    <input type="text" required class="form-control" id="nom" name="nom">
                </div>
                <div class="form-group">
                    <label for="prenom">Votre prénom</label>
                    <input type="text" required class="form-control" id="prenom" name="prenom">
                </div>
                <div class="form-group">
                    <label for="email">Votre adresse mail</label>
                    <input type="email" required class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="motdepasse">Votre mot de passe</label>
                    <input type="password" required class="form-control" id="texte" rows="2" name="motdepasse">
                </div>
                <button type="submit" class="btn btn-primary" name="submit" value="bouton">S'inscrire</button>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript -->

<?php echo '<script'; ?>
 src="vendor/jquery/jquery.slim.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="vendor/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>

</body>
</html><?php }

}
