<?php

if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '',
  'unifunc' => '',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '' => 
    array (
      0 => 'C:\\wamp64\\www\\Blog\\Templates\\Index.tpl',
      1 => 'file',
    ),
  ),
  array (
  ),
),false)) {
function (Smarty_Internal_Template $_smarty_tpl) {

?>
<!-- Page Content -->

<div class="container">
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1 class="mt-5">Les articles qui ont été publiés</h1>
        </div>
    </div>
    
    <!-- Variable super globale $_session -->

    <?php if (isset($_SESSION['notification'])) {?>
        
        <!-- Notification -->

        <div class="row">
            <div class="col-12">
                <div class="alert alert-<?php echo $_SESSION['notification']['result'];?>
 alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <?php echo $_SESSION['notification']['message'];?>

                </div>
            </div>
        </div>
        
    <?php }?>
    <div class="row">
     
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab_result']->value, 'value');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['value']->value) {
?> 
            
            <div class="col-6">
                <div class="card" style="width: 100%;">
                    <img class="card-img-top" src="img/<?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['value']->value['titre'];?>
">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $_smarty_tpl->tpl_vars['value']->value['titre'];?></h5>
                        <p class="card-text"><?php echo $_smarty_tpl->tpl_vars['value']->value['texte'];?></p>
                        <a href="#" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['value']->value['date_fr'];?></a> 
                        
                        <!-- Dans le cas où la connexion est OK -->

                        <?php if ($_smarty_tpl->tpl_vars['connecte']->value == true) {?>
                        <a href="article.php?id=<?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
                        &action=modifier" class="btn btn-primary">Modifier l'article</a>
                        <a href="afficher.php?id=<?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
                        &action=afficher" class="btn btn-primary">Afficher l'article</a>
                        <a href="supprimer.php?id=<?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
                        &action=supprimer" class="btn btn-primary">Supprimer l'article</a>
                        <?php }?>
                    </div>
                </div>
            </div>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>
</div>

<!-- Bootstrap core JavaScript -->

<?php echo '<script'; ?>
 src="vendor/jquery/jquery.slim.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="vendor/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>

</body>
</html>

<?php }

}
