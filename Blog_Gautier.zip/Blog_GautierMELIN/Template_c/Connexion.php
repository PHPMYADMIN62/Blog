<?php

if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '',
  'unifunc' => '',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '' => 
    array (
      0 => 'C:\\wamp64\\www\\Blog\\Templates\\Utilisateur.tpl',
      1 => 'file',
    ),
  ),
  array (
  ),
),false)) {
function (Smarty_Internal_Template $_smarty_tpl) {

?>

<!-- Page Content -->

<div class="container">
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1 class="mt-5">Authentification</h1>
        </div>
    </div>

    <!-- Affiche une fenêtre d'authentification -->

    <div class="row">
        <div class="col-12">
            <form method="POST" action="Connexion.php" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="email">Indiquez votre adresse mail</label>
                    <input type="email" required class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="motdepasse">Indiquez votre mot de passe</label>
                    <input type="password" required class="form-control" id="texte" rows="3" name="motdepasse">
                </div>
                <button type="submit" class="btn btn-primary" name="submit" value="bouton">Je me connecte</button>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript -->

<?php echo '<script'; ?>
 src="vendor/jquery/jquery.slim.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="vendor/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>

</body>
</html>

<?php }

}
