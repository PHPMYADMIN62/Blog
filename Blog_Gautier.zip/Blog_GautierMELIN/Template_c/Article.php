<?php

if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '',
  'unifunc' => '',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '' => 
    array (
      0 => 'C:\\wamp64\\www\\Blog\\Templates\\Article.tpl',
      1 => 'file',
    ),
  ),
  array (
  ),
),false)) {
function (Smarty_Internal_Template $_smarty_tpl) {
if (isset($_GET['action']) && isset($_GET['id'])) {?> 

?>

<!-- Modification d'un article -->

    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1 class="mt-5">Modification d'un article</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <form method="POST" action="Article.php?action=modifier&id=<?php echo $_GET['id'];?>
                    " enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $_GET['id'];?>">
                    <input type="hidden" name="action" value="<?php echo $_GET['action'];?>">
                    <div class="form-group">
                        <label for="titre">Le titre de l'article</label>
                        <input type="text" class="form-control" id="titre" name="titre" value="<?php echo $_smarty_tpl->tpl_vars['article']->value['titre'];?>">
                    </div>
                    <div class="form-group">
                        <label for="texte">Le contenu de l'article</label>
                        <textarea class="form-control" id="texte" rows="10" cols="100" name="texte"><?php echo $_smarty_tpl->tpl_vars['article']->value['texte'];?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="img">L'image de mon article</label>
                        <input type="file" class="form-control-file" id="img" name="img"">
                    </div>
                    <button type="submit" class="btn btn-primary" name="submit" value="bouton">Je modifie mon article</button>
                </form>
            </div>
        </div>
    </div>
<?php } else { ?>

<!-- Ajout d'un article -->

    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1 class="mt-5">Ajouter un nouvel article</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <form method="POST" action="Article.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="titre">Le titre de l'article</label>
                        <input type="text" class="form-control" id="titre" name="titre">
                    </div>
                    <div class="form-group">
                        <label for="texte">Le contenu de l'article</label>
                        <input type="textarea" class="form-control" id="texte" rows="3" name="texte">
                    </div>
                    <div class="form-group">
                        <label for="img">L'image de mon article</label>
                        <input type="file" class="form-control-file" id="img" name="img">
                    </div>
                    <button type="submit" class="btn btn-primary" name="submit" value="bouton">Ajouter mon article</button>
                </form>
            </div>
        </div>
    </div>
<?php }?>
    
<!-- Bootstrap core JavaScript -->

<?php echo '<script'; ?>
 src="vendor/jquery/jquery.slim.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="vendor/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>

</body>
</html>

<?php }

}
